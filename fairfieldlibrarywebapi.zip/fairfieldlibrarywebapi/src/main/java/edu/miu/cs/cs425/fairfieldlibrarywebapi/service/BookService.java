package edu.miu.cs.cs425.fairfieldlibrarywebapi.service;

import edu.miu.cs.cs425.fairfieldlibrarywebapi.model.Book;

public interface BookService {

    Book addNewBook(Book book);
}
