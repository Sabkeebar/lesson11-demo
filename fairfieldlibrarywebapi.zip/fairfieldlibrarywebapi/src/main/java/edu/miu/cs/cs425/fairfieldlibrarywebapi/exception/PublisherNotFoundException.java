package edu.miu.cs.cs425.fairfieldlibrarywebapi.exception;

public class PublisherNotFoundException extends Exception {

    public PublisherNotFoundException(String message) {
        super(message);
    }

}
