package edu.miu.cs.cs425.fairfieldlibrarywebapi.service;

import edu.miu.cs.cs425.fairfieldlibrarywebapi.model.PrimaryAddress;

public interface PrimaryAddressService {

    PrimaryAddress addNewPrimaryAddress(PrimaryAddress primaryAddress);
}
