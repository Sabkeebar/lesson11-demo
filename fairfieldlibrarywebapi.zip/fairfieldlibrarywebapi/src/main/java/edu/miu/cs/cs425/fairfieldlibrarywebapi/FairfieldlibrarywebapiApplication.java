package edu.miu.cs.cs425.fairfieldlibrarywebapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FairfieldlibrarywebapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FairfieldlibrarywebapiApplication.class, args);
    }

}
